import { IWebpackCLI } from "webpack-cli";
declare class ConfigTestCommand {
    apply(cli: IWebpackCLI): Promise<void>;
}
export default ConfigTestCommand;
