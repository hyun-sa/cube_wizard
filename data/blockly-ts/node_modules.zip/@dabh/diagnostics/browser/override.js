var diagnostics = require('./');

//
// No way to override `debug` with `diagnostics` in the browser.
//
module.exports = diagnostics;
