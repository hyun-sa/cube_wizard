module.exports = () => {
    throw new Error('Method is not supported');
};
